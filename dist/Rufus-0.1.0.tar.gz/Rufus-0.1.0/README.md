# Rufus: Web Crawler supported by LLM for Q&A

-----

### Current Development:

- Asynchronous Web Crawler.
- Structured and Unstructured Data parsing and formatting
- Context-aware Crawling